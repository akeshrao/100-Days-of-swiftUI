import Cocoa

var day = ["Monday","Tuseday","Wednesday","Thursday","Friday","Saturday"]
let number = [0,1,2,3,5,6]
var money = [10.5,22.6,28.9,62.7,89.10,26.1]

day.append("Holiday")
day.append("NewDay")

//how to add in array use Array name.append
var carnames = [String]()
carnames.append("Lamborgibni")
carnames.append("BMW")
carnames.append("Pagani")

day.append("Sunday")

print(carnames)
print(carnames[1])

//how to count an array usne Array name.count
print(day.count)

//how to sort and array use Array name.sorted()
print(money)
print(money.sorted())

//how to find if things in array use array name.contains("thing your looking for??")
print(day.contains("Sunday"))
print(day.contains("New year"))

// how to revers an array use Array name.reversed
print(day)
day.reverse()
print(day)

//Dictionaries

let student1 = ["Name":"Akesh Rao","Age":"26","Class":"10th","Div":"A"]
print(student1["Name", default: "Unknown"])

var newdictionary = [String:Int]()
newdictionary["Vcore"] = 6
newdictionary["VRam"] = 8
newdictionary["VHDD"] = 250
print(newdictionary)
print(newdictionary.reversed())


//Sets - Faster then Array||Does not coantains dupilcates

let mycrusname = (["Soney","Rashi","Kifa","Aarti","dipti","payal","micky","rudira","pranali","alifya","shrusti","Neha","krutika","Anna"])
print(mycrusname)


var UserID = Set<String>()
UserID.insert("CIPL01")
UserID.insert("CIPL02")
UserID.insert("CIPL03")

print(UserID)


//enum - its like creating an list / Dropdown list to avoid writing and wrong data

enum weekdays {case Monday, tuesday, wednesday, thursday, friday, saturday, sunday}

var Days = weekdays.Monday
var Days2 = weekdays.sunday

print(Days2)


//check point 2 create an array of strings, then write some code that prints the number of items in the array and also the number of unique items in the array.



var ThingsLearned = [String]()
ThingsLearned.append("Array")
ThingsLearned.append("Discsanary")
ThingsLearned.append("Sets")
ThingsLearned.append("Enums")
ThingsLearned.append("variabel")
ThingsLearned.append("constant")
ThingsLearned.append("Int")
ThingsLearned.append("string")
ThingsLearned.append("boolian")
ThingsLearned.append("doubles")
ThingsLearned.append("float")
ThingsLearned.append("float")

print(ThingsLearned)

print(ThingsLearned.count)
let UTL = Set(ThingsLearned)
print(UTL)
print(UTL.count)
